export const exampleTasks = [
  {
    id: 1,
    title: 'Hi ✌︎',
    prority: 3,
    completed: false,
    dateAdded: new Date('1/1/2020 00:06'),
  },
  {
    id: 2,
    title: 'Welcome to Matter',
    prority: 7,
    completed: false,
    dateAdded: new Date('1/1/2020 00:05'),
  },
  {
    id: 3,
    title: 'No account needed',
    prority: 4,
    completed: false,
    dateAdded: new Date('1/1/2020 00:04'),
  },
  {
    id: 4,
    title: 'Click here to edit the title',
    prority: 2,
    completed: false,
    dateAdded: new Date('1/1/2020 00:03'),
  },
  {
    id: 5,
    title: 'Resize the circle to indicate priority',
    prority: 6,
    completed: false,
    dateAdded: new Date('1/1/2020 00:02'),
  },
  {
    id: 6,
    title: 'Try dark mode',
    prority: 1,
    completed: false,
    dateAdded: new Date('1/1/2020 00:01'),
  },
]
